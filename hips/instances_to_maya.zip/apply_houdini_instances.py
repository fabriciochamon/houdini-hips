# usage:
#  1- export .abc from houdini using "instances to maya" hda
#  2- import .abc into maya
#  3- select imported  top node and run this script

import maya.cmds as cmds

mapped_attributes = {
    'pscale':                {'maya_name': 'radiusPP',          'type': 'scalar',    'drive_instancer_attr': 'scale'},
    'maya_rotationPP':       {'maya_name': 'rotationPP',        'type': 'vec3',      'drive_instancer_attr': 'rotation'},
    'maya_velocity':         {'maya_name': 'velocity',          'type': 'vec3',      'drive_instancer_attr': None},
    'maya_rgbPP':            {'maya_name': 'rgbPP',             'type': 'vec3',      'drive_instancer_attr': None},
    'maya_finalLifespanPP':  {'maya_name': 'finalLifespanPP',   'type': 'scalar',    'drive_instancer_attr': None},
    'maya_instanceId':       {'maya_name': 'instanceId',        'type': 'scalar',    'drive_instancer_attr': None},
    'maya_age':              {'maya_name': 'age',               'type': 'scalar',    'drive_instancer_attr': None},
    'maya_visibility':       {'maya_name': 'visibility',        'type': 'scalar',    'drive_instancer_attr': 'visibility'},
}

parent_node = cmds.ls(selection=True)
if len(parent_node):
    
    # get particle shapes
    parent_node = parent_node[0]
    shapes = cmds.listRelatives(parent_node, ad=True, type='shape')
    instancefile_nodes = []
        
    # loop over all shapes
    for n, shape in enumerate(shapes):
        
        particle_count = cmds.particle(shape, query=True, count=True)
        attrs = cmds.listAttr(shape, userDefined=True)
        attrs = [item for item in attrs if not item.endswith('_AbcGeomScope')]
               
        # loop over abc user defined attributes, copy them to particle attributes
        for attr_name in attrs:
            
            # check if attribute has actual values, skip otherwise
            try:
                attr = cmds.getAttr(f'{shape}.{attr_name}')
            except:
                continue
                
            # if attribute should be mapped, apply to particles    
            if attr_name in mapped_attributes.keys():
                data_type = mapped_attributes[attr_name]['type']
                maya_attr_name = mapped_attributes[attr_name]['maya_name']
                
                # check if corresponding particle attribute exists, create otherwise
                particle_attr_exists = cmds.attributeQuery(maya_attr_name, node=shape, exists=True)
                if not particle_attr_exists:
                    dt = 'doubleArray' if data_type == 'scalar' else 'vectorArray'
                    cmds.addAttr(shape, ln=maya_attr_name, dt=dt)
                
                # map attribute values
                for i in range(particle_count):
                    cmds.select( f'{shape}.pt[{i}]' )
                    if data_type == 'scalar':
                        cmds.setParticleAttr(at=maya_attr_name, fv=attr[i])
                    elif data_type == 'vec3':
                        idx = i*3
                        value = tuple(attr[idx:idx+3])
                        cmds.setParticleAttr(at=maya_attr_name, vv=value)
                
                # debug        
                #values = cmds.getAttr(f'{shape}.{maya_attr_name}')
                #print(f'Mapped attribute "{attr_name}" -> "{maya_attr_name}" with values:\n{values}')
        
        # get shape parents
        parent_object = cmds.listRelatives(shape, parent=True)[0]
        cmds.hide(parent_object)
        parent_parent_object = cmds.listRelatives(parent_object, parent=True)[0]
        
        # if has "instancefile" attribute, load file 
        has_instancefile = 'instancefile' in attrs
        geo_node = None
        if has_instancefile:
            geo_node = cmds.createNode('transform', name=f'{parent_object}_master', parent=parent_parent_object)
            instancefile = cmds.getAttr(f'{shape}.instancefile')
            instancefile_node = cmds.AbcImport(instancefile, mode='import', rpr=geo_node)
            instancefile_nodes.append(geo_node)
        
        # create point instancer, and possibly assign instance file
        if has_instancefile:
            instancer_node = cmds.particleInstancer(shape, name=f'{parent_object}_instancer', scale='radiusPP', rotation='rotationPP', visibility='visibility', addObject=True, object=geo_node)
        else:
            instancer_node = cmds.particleInstancer(shape, name=f'{parent_object}_instancer', scale='radiusPP', rotation='rotationPP', visibility='visibility')
        cmds.parent(instancer_node, parent_parent_object)
        
    # hide master instances
    for node in instancefile_nodes:
        cmds.hide(node)
        
    cmds.select(clear=True)
        
        

                        
    
                
